import UIKit

extension UITextField
{
    func useUnderline() {
        let border = CALayer()
        let borderWidth = CGFloat(1.0)
        border.borderColor = UIColor.lightGray.cgColor
        border.frame = CGRect(origin: CGPoint(x: 0,y :self.frame.size.height - borderWidth), size: CGSize(width: self.frame.size.width, height: self.frame.size.height))
        border.borderWidth = borderWidth
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
}
class UserLoginViewController: UIViewController {

    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        loginView.layer.cornerRadius = 10
        txtEmail.becomeFirstResponder()
        txtEmail.useUnderline()
        txtPassword.useUnderline()
        txtEmail.leftViewMode = .always
        let imgEmailView = UIImageView(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        imgEmailView.image = UIImage(named: "iconfinder_message_1954542.png")
        txtEmail.leftView = imgEmailView
        txtPassword.leftViewMode = .always
        let imgPassView = UIImageView(frame: CGRect(x: 0, y: 0, width: 32, height: 32))
        imgPassView.image = UIImage(named: "iconfinder_lock_115716.png")
        txtPassword.leftView = imgPassView
    }
}
