//
//  UserRegistrationModel.swift
//  StartVotting
//
//  Created by MAC2 on 10/12/18.
//  Copyright © 2018 MAC2. All rights reserved.
//

import UIKit

class UserRegistrationModel: NSObject {

}
