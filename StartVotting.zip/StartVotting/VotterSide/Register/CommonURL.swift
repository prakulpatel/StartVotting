import Foundation

func getUrl() -> String {
    
    let strUrl : String = "http://localhost/StartVotting/"
    return strUrl
}
