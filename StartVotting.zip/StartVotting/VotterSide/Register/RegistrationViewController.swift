import UIKit

class RegistrationViewController: UIViewController, RegistrationDelegate {

    @IBOutlet weak var registView: UIView!
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtMobileNo: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtBirthDate: UITextField!
    var gender : String = ""
    var dtPicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registView.clipsToBounds = true
        registView.layer.cornerRadius = 10
        
        createToolbar()
    }
    func createToolbar()  {
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let done = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(self.showDate))
        toolbar.setItems([done], animated: false)
        txtBirthDate.inputAccessoryView = toolbar
        txtBirthDate.inputView = dtPicker
        dtPicker.datePickerMode = .date
    }
    @objc func showDate() {
        
        let dt = dtPicker.date
        let formattor = DateFormatter()
        formattor.dateFormat = "dd-MM-yyyy"
        txtBirthDate.text = formattor.string(from: dt)
        self.view.endEditing(true)
    }
    @IBAction func btnInsertData(_ sender: Any) {
    
        phoneCheck()
    }
    func phoneCheck() {
        
        let obPhone = RegistrationModel(mobile: txtMobileNo.text!)
        let obRegist = RegistrationController()
        obRegist.delegate = self
        obRegist.phoneCheck(ob: obPhone, path: "VotterPhoneCheck.php")
    }
    func insertData() {
        
        let obRegist = RegistrationController()
        obRegist.delegate = self
        let obData = RegistrationModel(username: txtUserName.text!, email: txtEmail.text!, mobile: txtMobileNo.text!, city: txtCity.text!, password: txtPassword.text!, b_date: txtBirthDate.text!, gender: gender)
        obRegist.insertData(ob: obData, path: "VotterRegistration.php")
    }
    func getResponseString(str: String) {
        if str == "Inserted" {
            let alert = UIAlertController(title: "Thank you!", message: "Successfully Registred", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Next", style: .default, handler: nil))
            self.present(alert, animated: true) {
                alert.view.isUserInteractionEnabled = true
                alert.view.superview?.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.dismissAlert)))
            }
        }
    }
    @objc func dismissAlert() {
        
        self.dismiss(animated: true, completion: nil)
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count == 1 {
            let alert = UIAlertController(title: "This is title", message: "This is message", preferredStyle: .alert)
            self.present(alert, animated: true, completion:{
                alert.view.superview?.isUserInteractionEnabled = true
                alert.view.superview?.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.dismissAlert)))
            })
        }else{
            insertData()
        }
    }
    @IBAction func btnMale(_ sender: Any) {
    
        gender = "Male"
    }
    @IBAction func btnFemale(_ sender: Any) {
        
        gender = "Female"
    }
    @IBAction func btnOther(_ sender: Any) {
        
        gender = "Other"
    }
}
