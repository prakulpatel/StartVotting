import UIKit

@objc protocol RegistrationDelegate {
    
    @objc optional func getResponseString(str : String)
    @objc optional func getResponseData(arrDisc : [[String:Any]])
}
class RegistrationController: NSObject {

    var delegate : RegistrationDelegate?
    
    func insertData(ob : RegistrationModel,path : String) {
        
        let str = getUrl()
        let strUrl = str.appending(path)
        let disc : [String:Any] = ["username":ob.username!,"city":ob.city!,"b_date":ob.b_date!,"email":ob.email!,"mobile":ob.mobile!,"password":ob.password!,"gender" : ob.gender!]
        do {
            var strBody = try JSONSerialization.data(withJSONObject: disc, options: [])
            let url = URL(string: strUrl)
            let session = URLSession.shared
            var request = URLRequest(url: url!)
            request.addValue(String(strBody.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = strBody
            request.httpMethod = "POST"
            let dataTask = session.dataTask(with: request) { (data1, resp1, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                DispatchQueue.main.async {
                    if result == "Inserted"{
                        
                        self.delegate?.getResponseString!(str: result!)
                    }
                }
            }
            dataTask.resume()
        } catch  {
            
        }
    }
    func phoneCheck(ob : RegistrationModel,path : String) {
        
        let str = getUrl()
        let strUrl = str.appending(path)
        let disc : [String:Any] = ["mobile":ob.mobile!]
        do {
            var strBody = try JSONSerialization.data(withJSONObject: disc, options: [])
            let url = URL(string: strUrl)
            let session = URLSession.shared
            var request = URLRequest(url: url!)
            request.addValue(String(strBody.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = strBody
            request.httpMethod = "POST"
            let dataTask = session.dataTask(with: request) { (data1, resp1, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                do{
                    let jsonData = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                    DispatchQueue.main.async {
                        if jsonData.count == 0{
                            
                            self.delegate?.getResponseData!(arrDisc: jsonData)
                        }
                    }
                }catch{
                    
                }
            }
            dataTask.resume()
        } catch  {
            
        }
    }
}
