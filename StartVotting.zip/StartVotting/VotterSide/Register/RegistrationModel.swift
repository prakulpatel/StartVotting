import UIKit

class RegistrationModel: NSObject {

    var username : String?
    var email : String?
    var mobile : String?
    var city : String?
    var password : String?
    var b_date : String?
    var gender : String?
    
    init(username : String,email : String,mobile : String,city : String,password : String,b_date : String,gender : String) {
        
        self.username = username
        self.email = email
        self.mobile = mobile
        self.city = city
        self.password = password
        self.b_date = b_date
        self.gender = gender
    }
    init(mobile : String) {
        
        self.mobile = mobile
    }
}
