import UIKit

class ViewController: UIViewController {

    var spinner = ALThreeCircleSpinner()
    var time = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        startProcess()
    }
    func startProcess() {
        
        spinner = ALThreeCircleSpinner(frame: CGRect(x: 155, y: 570, width: 50, height: 50))
        spinner.tintColor = UIColor.red
        self.view.addSubview(spinner)
        time = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.showProcess), userInfo: nil, repeats: true)
    }
    @objc func showProcess() {
        
        spinner.stopAnimating()
        spinner.hidesWhenStopped = true
        time.invalidate()
        let story = self.storyboard?.instantiateViewController(withIdentifier: "UserLoginViewController") as! UserLoginViewController
        self.navigationController?.pushViewController(story, animated: true)
        //print("completed")
    }
}

